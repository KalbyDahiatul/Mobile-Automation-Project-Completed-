package MyDemoApp;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class MobileAppAutomationTest {

	public AndroidDriver driver;

	@SuppressWarnings("deprecation")
	@BeforeClass
	public void setUp() throws MalformedURLException {
		// Set up DesiredCapabilities for Appium driver
		DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
		desiredCapabilities.setCapability("appium:deviceName", "Pixel9");
		desiredCapabilities.setCapability("platformName", "android");
		desiredCapabilities.setCapability("appium:automationName", "UiAutomator2");
		desiredCapabilities.setCapability("appium:appPackage", "com.saucelabs.mydemoapp.rn");
		desiredCapabilities.setCapability("appium:appActivity", "com.saucelabs.mydemoapp.rn.MainActivity");
		desiredCapabilities.setCapability("appium:udid", "emulator-5554");
		// Initialize the Appium driver
		URL remoteUrl = new URL("http://127.0.0.1:4723");
		driver = new AndroidDriver(remoteUrl, desiredCapabilities);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println("Driver initialized and setup completed");
	}

	@Test
	public void testMobileAppAutomation() throws InterruptedException {
		// Step 1: Verify Products page
		Thread.sleep(3000); // Wait for Products page to load
		System.out.println("Enter the shopping apps");
		WebElement productsPageTitle = driver.findElement(By.xpath("//android.widget.TextView[@text='Products']"));
		String productsTitle = productsPageTitle.getText();
		System.out.println("Page title is: " + productsTitle);
		Assert.assertEquals(productsTitle, "Products", "Failed to verify Products page title");

		// Step 2: Select the first product
		Thread.sleep(3000); // Wait before selecting the product
		driver.findElement(By.xpath(
				"(//android.view.ViewGroup[@content-desc='store item'])[1]/android.view.ViewGroup[1]/android.widget.ImageView"))
				.click();
		System.out.println("Selected the first product");

		// Verify product details page
		Thread.sleep(3000); // Wait for the product details page
		WebElement productDetails = driver
				.findElement(By.xpath("//android.widget.TextView[@text='Sauce Labs Backpack']"));
		String productTitle = productDetails.getText();
		System.out.println("Product title is: " + productTitle);
		Assert.assertEquals(productTitle, "Sauce Labs Backpack", "Failed to verify selected product title");
		System.out.println("Hard Assertion Done : Verified product details page");
		// Add the product to the cart
		driver.findElement(By.xpath("//android.widget.TextView[@text='Add To Cart']")).click();
		System.out.println("Added first product to cart");
		Thread.sleep(5000);

		// Step 3: Navigate to cart
		driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc='cart badge']/android.widget.ImageView"))
				.click();
		System.out.println("Navigated to cart");
		Thread.sleep(5000);

		// Verify cart page
		WebElement cartPageTitle = driver.findElement(By.xpath("//android.widget.TextView[@text='My Cart']"));
		String cartTitle = cartPageTitle.getText();
		System.out.println("Cart page title is: " + cartTitle);
		Assert.assertEquals(cartTitle, "My Cart", "Failed to verify Cart page title");
		System.out.println("Hard Assertion done : Verified cart page title");

		// Step 4: Navigate back to Products and add another product
		driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"open menu\"]/android.widget.ImageView"))
				.click();
		Thread.sleep(3000); // Wait for the menu to open
		System.out.println("Opened The Hamburger menu");

		driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc=\"open menu\"]")).click();
		Thread.sleep(5000); // Wait for the Products page to load
		System.out.println("Returned to Products page");

		driver.findElement(By.xpath(
				"(//android.view.ViewGroup[@content-desc='store item'])[2]/android.view.ViewGroup[1]/android.widget.ImageView"))
				.click();
		System.out.println("Selected second product");

		// Add the second product to the cart
		driver.findElement(By.xpath("//android.widget.TextView[@text='Add To Cart']")).click();
		System.out.println("Added second product to cart");
		Thread.sleep(5000);

		// Navigate back to cart
		driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc='cart badge']/android.widget.ImageView"))
				.click();
		System.out.println("Navigated back to cart");
		Thread.sleep(5000);

		// Step 5: Proceed to checkout
		driver.findElement(By.xpath("//android.widget.TextView[@text='Proceed To Checkout']")).click();
		System.out.println("Proceeded to Checkout");
		Thread.sleep(5000);

		// Verify login page
		WebElement loginPageTitle = driver.findElement(By.xpath("//android.widget.TextView[@text='Login']"));
		String loginTitle = loginPageTitle.getText();
		System.out.println("Login page title is: " + loginTitle);
		Assert.assertEquals(loginTitle, "Login", "Failed to verify Login page title");
		System.out.println("Hard Assertion done : Verified login page");

		// Step 6: Login
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Username input field']"))
				.sendKeys("bob@example.com");
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Password input field']"))
				.sendKeys("10203040");
		driver.findElement(By.xpath("//android.view.ViewGroup[@content-desc='Login button']")).click();
		System.out.println("Login completed");
		Thread.sleep(5000);

		// Step 7: Fill checkout form and proceed to payment
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Full Name* input field']"))
				.sendKeys("Rebecca Winter");
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Address Line 1* input field']"))
				.sendKeys("123 Demo Street");
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='City* input field']")).sendKeys("Dhaka");
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='State/Region input field']"))
				.sendKeys("Mirpur 1");
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Zip Code* input field']"))
				.sendKeys("1205");
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Country* input field']"))
				.sendKeys("Bangladesh");
		driver.findElement(By.xpath("//android.widget.TextView[@text='To Payment']")).click();
		System.out.println("Filled checkout form and proceeded to payment");
		Thread.sleep(5000);

		// Step 8: Complete payment
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"Full Name* input field\"]"))
				.sendKeys("Kalby Dahiatul"); // Update with a valid card number format for testing
		System.out.println("Entered Full Name");

		driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"Card Number* input field\"]"))
				.sendKeys("1234 1234 1234 123"); // Update with a valid card number format for testing
		System.out.println("Entered card number");

		driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"Expiration Date* input field\"]"))
				.sendKeys("12/25"); // Update expiration date
		System.out.println("Entered expiration date");

		driver.findElement(By.xpath("//android.widget.EditText[@content-desc=\"Security Code* input field\"]"))
				.sendKeys("123"); // Update security code
		System.out.println("Entered security code");

		driver.findElement(By.xpath("//android.widget.TextView[@text=\"Review Order\"]")).click(); // Proceed to review
		System.out.println("Clicked on Review Order");
		Thread.sleep(5000);

		driver.findElement(By.xpath("//android.widget.TextView[@text=\"Place Order\"]")).click(); // Place the order
		System.out.println("Order placed successfully");
		Thread.sleep(5000);

		WebElement orderConfirmationMessage = driver
				.findElement(By.xpath("//android.widget.TextView[@text='Thank you for your order']"));
		String confirmationText = orderConfirmationMessage.getText();
		System.out.println("Order confirmation message: " + confirmationText);
		Assert.assertEquals(confirmationText, "Thank you for your order",
				"Order confirmation message is not as expected");
		System.out.println("Hard Assertion done: Verified order confirmation message");

	}

	@AfterClass
	public void tearDown() {
		if (driver != null) {
			driver.quit();
			System.out.println("Driver quit and resources cleaned up");
		}
	}
}
